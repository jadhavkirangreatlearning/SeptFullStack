import axios from 'axios'

const EMPLOYEE_BASE_REST_API_URL = 'http://localhost:8080/api/';

class EmployeeService{

    getAllEmployees(){
        return axios.get(EMPLOYEE_BASE_REST_API_URL)
    }

    createEmployee(employee){
        return axios.post(EMPLOYEE_BASE_REST_API_URL, employee)
    }

    getEmployeeById(empId){
        return axios.get(EMPLOYEE_BASE_REST_API_URL + empId);
    }

    updateEmployee(empId, employee){
        return axios.put(EMPLOYEE_BASE_REST_API_URL + empId, employee);
    }

    deleteEmployee(empId){
        return axios.delete(EMPLOYEE_BASE_REST_API_URL +  empId);
    }
}

export default new EmployeeService();